import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators,FormBuilder } from '@angular/forms';
import { PostService } from '../../services/post.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute,Router } from '@angular/router';
import { AngularEditorConfig } from '@kolkov/angular-editor';

@Component({
  selector: 'app-editpost',
  templateUrl: './editpost.component.html',
  styleUrls: ['./editpost.component.css']
})
export class EditpostComponent implements OnInit {
 
  submitted = false;
  error;
  postid;
  post;
  userid = localStorage.getItem('id');
  editpostForm = this.fb.group({
  	  userid: [this.userid],
	  title: ['', [Validators.required]],
	  subtitle: ['', [Validators.required]],
	  content: ['', [Validators.required]],
	  tags: ['', [Validators.required]],
	});

	config: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: '15rem',
    minHeight: '5rem',
    placeholder: 'Enter text here...',
    translate: 'no',
    defaultParagraphSeparator: 'p',
    defaultFontName: 'Arial',
    toolbarHiddenButtons: [
      ['bold']
      ],
    customClasses: [
      {
        name: "quote",
        class: "quote",
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: "titleText",
        class: "titleText",
        tag: "h1",
      },
    ]
  };

  constructor(private fb: FormBuilder,private postService: PostService,private toastr: ToastrService,private router: Router,private route: ActivatedRoute) { 

  }

  ngOnInit(): void {

  	if(localStorage.getItem('isLoggedIn') !== 'true')
       {
           this.router.navigate(['/login']);
           return;
       }

    this.postid = this.route.snapshot.paramMap.get("postid");

    this.postService.getPost(this.postid).subscribe((data:any)=>{

        this.post = data;
        this.editpostForm.controls.title.setValue(data.Title);
        this.editpostForm.controls.subtitle.setValue(data.SubTitle);
        this.editpostForm.controls.content.setValue(data.Content);
        this.editpostForm.controls.tags.setValue(data.tags);


    });
  }

   get f() { return this.editpostForm.controls; }

   onSubmit() {
   
    this.error  = ''; 

    this.submitted = true;

	 if (this.editpostForm.invalid) {
            return;
        }


	this.postService.updatePost(this.editpostForm.value,this.postid).subscribe((data:any)=>{
	      if(data.status == true)
	      {
	        this.submitted = false;
	        this.editpostForm.reset();
	        this.toastr.success('Post Updated Successfully');
	        this.router.navigate(['/posts']);
	      }
	      if(data.status == false)
	      {
	        this.submitted = true;
	        this.error  = data.error; 
	        this.toastr.warning(this.error);
	      }
	      
	    });
	}


}
