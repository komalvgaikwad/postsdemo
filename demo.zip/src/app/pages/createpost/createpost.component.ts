import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators,FormBuilder } from '@angular/forms';
import { PostService } from '../../services/post.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { AngularEditorConfig } from '@kolkov/angular-editor';

@Component({
  selector: 'app-createpost',
  templateUrl: './createpost.component.html',
  styleUrls: ['./createpost.component.css']
})
export class CreatepostComponent implements OnInit {
 
  submitted = false;
  error;
  userid = localStorage.getItem('id');
  createpostForm = this.fb.group({
  	  userid: [this.userid],
	  title: ['', [Validators.required]],
	  subtitle: ['', [Validators.required]],
	  content: ['', [Validators.required]],
	  tags: ['', [Validators.required]],
	});

	config: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: '15rem',
    minHeight: '5rem',
    placeholder: 'Enter text here...',
    translate: 'no',
    defaultParagraphSeparator: 'p',
    defaultFontName: 'Arial',
    toolbarHiddenButtons: [
      ['bold']
      ],
    customClasses: [
      {
        name: "quote",
        class: "quote",
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: "titleText",
        class: "titleText",
        tag: "h1",
      },
    ]
  };

  constructor(private fb: FormBuilder,private postService: PostService,private toastr: ToastrService,private router: Router) { 

  }

  ngOnInit(): void {

  	if(localStorage.getItem('isLoggedIn') !== 'true')
       {
           this.router.navigate(['/login']);
           return;
       }
  }

   get f() { return this.createpostForm.controls; }

   onSubmit() {
   
    this.error  = ''; 

    this.submitted = true;

	 if (this.createpostForm.invalid) {
            return;
        }


	this.postService.createPost(this.createpostForm.value).subscribe((data:any)=>{
	      if(data.status == true)
	      {
	        this.submitted = false;
	        this.createpostForm.reset();
	        this.toastr.success('Post Created Successfully');
	        this.router.navigate(['/posts']);
	      }
	      if(data.status == false)
	      {
	        this.submitted = true;
	        this.error  = data.error; 
	        this.toastr.warning(this.error);
	      }
	      
	    });
	}


}
