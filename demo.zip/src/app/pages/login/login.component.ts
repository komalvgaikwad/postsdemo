import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators,FormBuilder } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  submitted = false;
  error;
  loginForm = this.fb.group({
	  email: ['', [Validators.required,Validators.email]],
	  password: ['', [Validators.required]],
	});
  constructor(private fb: FormBuilder,private authService: AuthService,private toastr: ToastrService,private router: Router) { }

  ngOnInit(): void {

  	if(localStorage.getItem('isLoggedIn') == 'true')
	   {
	       this.router.navigate(['/posts']);
	       return;
	   }
  }

  get f() { return this.loginForm.controls; }

  onSubmit() {
   
     this.error  = ''; 
   

   this.submitted = true;

	 if (this.loginForm.invalid) {
            return;
        }

       
	this.authService.login(this.loginForm.value).subscribe((data:any)=>{
      if(data.status == true)
      {
        this.submitted = false;
        this.loginForm.reset();
        this.toastr.success("Logged In Successfully"); 
        localStorage.setItem('isLoggedIn', "true");
        localStorage.setItem('id', data.user.Id);
        localStorage.setItem('name', data.user.Name);
        localStorage.setItem('email', data.user.Email);
        this.router.navigate(['/posts']);
        
      }
      if(data.status == false)
      {
        this.submitted = true;
        this.error  = data.error; 
        this.toastr.warning(this.error);
      }
      
    });
	}

}
