import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators,FormBuilder } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
 
  submitted = false;
  error;
  signupForm = this.fb.group({
	  name: ['', [Validators.required,Validators.pattern("^[a-zA-Z ]*$")]],
	  email: ['', [Validators.required,Validators.email]],
	  password: ['', [Validators.required,Validators.minLength(6)]],
	  cpassword: ['', [Validators.required]],
	});
  constructor(private fb: FormBuilder,private authService: AuthService,private toastr: ToastrService,private router: Router) { 

  }

  ngOnInit(): void {

  	if(localStorage.getItem('isLoggedIn') == 'true')
       {
           this.router.navigate(['/posts']);
           return;
       }
  }

   get f() { return this.signupForm.controls; }

   onSubmit() {
   
    this.error  = ''; 

    this.submitted = true;

	 if (this.signupForm.invalid) {
            return;
        }




    if(this.signupForm.value.password !== this.signupForm.value.cpassword)
    {
       this.error = 'Password and confirm password should be same';
        this.toastr.warning(this.error);
       return; 
    }

	this.authService.signup(this.signupForm.value).subscribe((data:any)=>{
	      if(data.status == true)
	      {
	        this.submitted = false;
	        this.signupForm.reset();
	        this.toastr.success('registered Successfully');
	        this.router.navigate(['/login']);
	      }
	      if(data.status == false)
	      {
	        this.submitted = true;
	        this.error  = data.error; 
	        this.toastr.warning(this.error);
	      }
	      
	    });
	}


}
