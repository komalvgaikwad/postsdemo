import { Component, OnInit } from '@angular/core';
import { PostService } from '../../services/post.service';
import { FormGroup, FormControl,Validators,FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  posts;
  searchForm = this.fb.group({
    keyword: ['']
  });
  keyword;
  constructor(private postService: PostService,private fb: FormBuilder) { }

  ngOnInit(): void {

       this.postService.getAllBlogPosts().subscribe((data:any)=>{
	        this.posts = data;
	    });
  }

  onSubmit() {

     this.keyword = (<HTMLInputElement>document.getElementById("search_input")).value ;
     this.searchForm.controls.keyword.setValue(this.keyword);
   
     this.postService.getAllBlogPostsByTag(this.searchForm.value).subscribe((data)=>{
      this.posts = data;
    });
    
  }

  clear()
  {

       (<HTMLInputElement>document.getElementById("search_input")).value = '';
          this.onSubmit();

  }


}
