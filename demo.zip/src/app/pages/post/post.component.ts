import { Component, OnInit } from '@angular/core';
import { PostService } from '../../services/post.service';
import { ActivatedRoute,Router } from '@angular/router';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {
  
  post;
  postid;
  constructor(private postService: PostService,private route: ActivatedRoute) { }

  ngOnInit(): void {

    this.postid = this.route.snapshot.paramMap.get("postid");
    this.postService.getPost(this.postid).subscribe((data:any)=>{
        this.post = data;
    });
  }

}
