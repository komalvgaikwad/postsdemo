import { Component, OnInit } from '@angular/core';
import { PostService } from '../../services/post.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl,Validators,FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {
  
  userid = localStorage.getItem('id');
  posts;
  searchForm = this.fb.group({
    keyword: ['']
  });
  keyword;
  constructor(private postService: PostService,private router: Router,private fb: FormBuilder) { }

  ngOnInit(): void {

  	if(localStorage.getItem('isLoggedIn') !== 'true')
       {
           this.router.navigate(['/login']);
           return;
       }

       this.postService.getAllBlogPostsByUser(this.userid).subscribe((data:any)=>{

	        this.posts = data;
	    });
  }

  deletePost(postid)
  {
     if(confirm("Are you sure?"))
     {
     	this.postService.deletePost(postid).subscribe((data:any)=>{

		     this.postService.getAllBlogPostsByUser(this.userid).subscribe((data:any)=>{

		        this.posts = data;
		    });
	    });
     }
  }

  onSubmit() {

     this.keyword = (<HTMLInputElement>document.getElementById("search_input")).value ;
     this.searchForm.controls.keyword.setValue(this.keyword);
   
     this.postService.getUserPostsByTag(this.searchForm.value,this.userid).subscribe((data)=>{
      this.posts = data;
    });
    
  }

  clear()
  {

       (<HTMLInputElement>document.getElementById("search_input")).value = '';
          this.onSubmit();

  }


}
