import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { SignupComponent } from './pages/signup/signup.component';
import { CreatepostComponent } from './pages/createpost/createpost.component';
import { EditpostComponent } from './pages/editpost/editpost.component';
import { PostComponent } from './pages/post/post.component';
import { PostsComponent } from './pages/posts/posts.component';

const routes: Routes = [
	{
		path: '',
		component: HomeComponent,
	},
	{
		path: 'login',
		component: LoginComponent,
	},
	{
		path: 'signup',
		component: SignupComponent,
	},
	{
		path: 'posts',
		component: PostsComponent,
	},
	{
		path: 'create-post',
		component: CreatepostComponent,
	},
	{
		path: 'edit-post/:postid',
		component: EditpostComponent,
	},
	{
		path: 'post/:postid',
		component: PostComponent,
	}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
