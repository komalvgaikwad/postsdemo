import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  base_url = 'http://localhost/api/auth/';
  constructor(private httpClient: HttpClient) { }

  /* sign up */
  public signup(formData){

   const formData1 = new FormData();

   formData1.append('name', formData.name);
   formData1.append('email', formData.email);
   formData1.append('password', formData.password);

   return this.httpClient.post(this.base_url+'signup',formData1);

  }
  
  /* login */
  public login(formData){


   const formData1 = new FormData();

   formData1.append('email', formData.email);
   formData1.append('password', formData.password);

    return this.httpClient.post(this.base_url+'login',formData1);
  }
}
