import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PostService {
  
  base_url = 'http://localhost/api/posts/';
  constructor(private httpClient: HttpClient) { }

  /* create post */
  public createPost(formData){

   const formData1 = new FormData();

   formData1.append('userid', formData.userid);
   formData1.append('title', formData.title);
   formData1.append('subtitle', formData.subtitle);
   formData1.append('content', formData.content);
   formData1.append('tags', formData.tags);

   return this.httpClient.post(this.base_url+'createPost',formData1);

  }

  /* update post */
  public updatePost(formData,postid){

   const formData1 = new FormData();

   formData1.append('userid', formData.userid);
   formData1.append('title', formData.title);
   formData1.append('subtitle', formData.subtitle);
   formData1.append('content', formData.content);
   formData1.append('tags', formData.tags);

   return this.httpClient.post(this.base_url+'updatePost/'+postid,formData1);

  }

   public deletePost(postid){
    return this.httpClient.get(this.base_url+'deletePost/'+postid);
  }

  public getPost(postid){
    return this.httpClient.get(this.base_url+'getPost/'+postid);
  }

  public getAllBlogPostsByUser(userid){
    return this.httpClient.get(this.base_url+'getAllBlogPostsByUser/'+userid);
  }

  public getUserPostsByTag(formData,userid){

    const formData1 = new FormData();
    formData1.append('keyword', formData.keyword);
    return this.httpClient.post(this.base_url+'getUserPostsByTag/'+userid,formData1);
  }

  public getAllBlogPosts(){
    return this.httpClient.get(this.base_url+'getAllBlogPosts');
  }

  public getAllBlogPostsByTag(formData){

    const formData1 = new FormData();
    formData1.append('keyword', formData.keyword);
    return this.httpClient.post(this.base_url+'getAllBlogPostsByTag',formData1);
  }
  
}
