<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
date_default_timezone_set('America/Chicago');

class User_model extends CI_Model
{

     function getUsers() {

        $this->db->select("*");
        $this->db->from('tbl_users');
        $this->db->where("IsDeleted","0");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        }
        return array();
    }

    function getUser($id,$column='Id',$shopid=0) {
        // Get a list of all categories
      $this->db->select("*");
      $this->db->from('tbl_users');
      $this->db->where($column,$id);
      $this->db->where('IsDeleted','0');
      $query = $this->db->get();
      return $query->row();
    }

    function addUser($data)
    {
        $this->db->insert('tbl_users', $data);
        return $this->db->insert_id();
    }
    function updateUser($data,$id)
    {
        $this->db->where("Id",$id);
        $this->db->update('tbl_users', $data);
    }
    function removeUser($id)
    {
        $this->db->where("Id",$id);
        $this->db->update('tbl_users', array('IsDeleted'=>'1'));
    } 

  

} 
?>