<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Post_model extends CI_Model
{

    function getPosts($tags='') {

        $this->db->select("p.*");
        $this->db->from('tbl_posts p');
        $this->db->join('tbl_post_tags t','p.Id=t.PostId','left');
        $this->db->where("p.IsDeleted","0");
        if (strlen($tags)>0) {
            $tagsarray = explode(',', $tags);
            foreach ($tagsarray as $key => $value) {
               $tagsarray[$key] = "'".$value."'";
            }
            $this->db->where("t.Tag IN (".implode(',', $tagsarray).")");
        }
        $this->db->order_by("p.Id","DESC");
        $this->db->group_by("p.Id");
        
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        }
        return array();
    }

    function getPostsByUser($userid,$tags='') {

        $this->db->select("p.*");
        $this->db->from('tbl_posts p');
        $this->db->join('tbl_post_tags t','p.Id=t.PostId','left');
        $this->db->where('p.UserId',$userid);
        $this->db->where("p.IsDeleted","0");
        if (strlen($tags)>0) {
            $tagsarray = explode(',', $tags);
            foreach ($tagsarray as $key => $value) {
               $tagsarray[$key] = "'".$value."'";
            }
            $this->db->where("t.Tag IN (".implode(',', $tagsarray).")");
        }
        $this->db->order_by("p.Id","DESC");
        $this->db->group_by("p.Id");
        
        $query = $this->db->get();
        //echo $this->db->last_query();
        if ($query->num_rows() > 0) {
            return $query->result();
        }
        return array();
    }


    function getPost($id,$column='Id') {
        // Get a list of all categories
       $this->db->select("p.*,u.Name");
       $this->db->from('tbl_posts p');
       $this->db->join('tbl_users u','p.UserId=u.Id','left');
       $this->db->where("p.IsDeleted","0");
       $this->db->where("p.".$column,$id);
       $query = $this->db->get();
       return $query->row();
    }

    function addPost($data)
    {
        $this->db->insert('tbl_posts', $data);
        return $this->db->insert_id();
    }
    function updatePost($data,$id)
    {
        $this->db->where("Id",$id);
        $this->db->update('tbl_posts', $data);
    }
    function removePost($id)
    {
        $this->db->where("Id",$id);
        $this->db->update('tbl_posts', array('IsDeleted'=>'1'));
    } 

    function getPostTags($id,$column='') {

        $this->db->select("*");
        $this->db->from('tbl_post_tags');
        $this->db->where($column,$id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        }
        return array();
    }


    function deletePostTags($postid)
    {
       $this->db->where('PostId',$postid);
       $this->db->delete('tbl_post_tags');
    }

    function addPostTags($array)
    {
        $this->db->insert_batch('tbl_post_tags', $array);
    }
} 
?>