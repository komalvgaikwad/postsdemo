<?php
defined("BASEPATH") OR exit("No direct script access allowed");
 date_default_timezone_set("Asia/Calcutta");


class Auth extends CI_Controller {

  /**
   * Index Page for this controller.
   *
   * Maps to the following URL
   *    http://example.com/index.php/welcome
   *  - or -
   *    http://example.com/index.php/welcome/index
   *  - or -
   * Since this controller is set as the default controller in
   * config/routes.php, it"s displayed at http://example.com/
   *
   * So any other public methods not prefixed with an underscore will
   * map to /index.php/welcome/<method_name>
   * @see https://codeigniter.com/user_guide/general/urls.html
   */
  function __construct()
  {
    parent::__construct();
    $this->load->model("user_model");
  }
  public function index()
  {
    
  }
  
  /* sign up */
  public function signup()
  {

    header('access-control-allow-origin: *');

    $post = $_POST;

    $user_email = $this->user_model->getUser($post['email'],'Email');

    if (count((array)$user_email)>0) {
      $result = array('status'=> false,'error'=>'Email Id already exists');
      echo json_encode($result);
    }
    else
    {

      $data = array(
          'Name'=> $post['name'],
          'Email'=> $post['email'],
          'Password'=> password_hash($post['password'], PASSWORD_DEFAULT),
        );


        $id = $this->user_model->addUser($data);

        if ($id > 0) {
          $status = true;
        }
        else
        {
          $status = false;
        }


        $result = array('status'=> $status);
        echo json_encode($result);

    }
      
  }

  /* login */
  public function login()
  {

    header('access-control-allow-origin: *');
    
    $post = $_POST;

    $user = $this->user_model->getUser($post['email'],'Email');

    if (count((array)$user)>0) {

      if (password_verify($post['password'], $user->Password)) {
        $result = array('status'=> true,'user'=>$user);
        echo json_encode($result);
      }
      else{
        $result = array('status'=> false,'error'=>'Invalid Password');
        echo json_encode($result);
      }
      
    }
    else{
       $result = array('status'=> false,'error'=>'Email No doesn\'t exists');
       echo json_encode($result);
    }
    
  }

    
}
