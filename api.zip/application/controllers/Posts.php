<?php
defined("BASEPATH") OR exit("No direct script access allowed");

class Posts extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it"s displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();
    $this->load->model("post_model");
		
	}
	public function index()
	{
		
	}

  /* create post */
  public function createPost()
  {

    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: *');
  
    $post = $_POST;

   $data = array(
          'UserId'=> $post['userid'],
          'Title'=> $post['title'],
          'SubTitle'=> $post['subtitle'],
          'Content'=> $post['content'],
        );



    $postid = $this->post_model->addpost($data); 

    $master_array = array();
    $tags = explode(',', $post['tags']);

    if (strlen($post['tags'])>0) {
      foreach ($tags as $key => $value) {
          
          $array = array('PostId'=>$postid,'Tag'=>trim($value));
          array_push($master_array,$array);
      }

      if (count($master_array)>0) {
        $this->post_model->addPostTags($master_array);
      }
    }
    

    $data = array('status'=>true);
    echo json_encode($data);

  }

  /* update post */
  public function updatePost($postid)
  {

    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: *');
  
    $post = $_POST;

    $data = array(
          'Title'=> $post['title'],
          'SubTitle'=> $post['subtitle'],
          'Content'=> $post['content'],
        );

   

    $this->post_model->updatepost($data,$postid);

    $this->post_model->deletePostTags($postid);

    $master_array = array();
    $tags = explode(',', $post['tags']);

    if (strlen($post['tags'])>0) {
      foreach ($tags as $key => $value) {
          
          $array = array('PostId'=>$postid,'Tag'=>trim($value));
          array_push($master_array,$array);
      }

      if (count($master_array)>0) {
        $this->post_model->addPostTags($master_array);
      }
    }
    

    $data = array('status'=>true);
    echo json_encode($data);

  }

  /* delete post */
  public function deletePost($postid)
  {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: *');
   
    $this->post_model->removepost($postid);
    $data = array('status'=>true);
    echo json_encode($data);
   
  }


  /* get all posts */
  public function getAllBlogPosts()
  {
    
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: *');
    $data = $this->post_model->getPosts();
    echo json_encode($data);

  }

  /* get posts created by logged in user */
  public function getAllBlogPostsByUser($userid)
  {
    
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: *');
    $data = $this->post_model->getPostsByUser($userid);
    echo json_encode($data);

  }

  /*get single post details */
  public function getPost($id)
  {
    
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: *');
    $data = $this->post_model->getpost($id);
    $data->tags = '';
    $tagsarray = array();
    $tags = $this->post_model->getPostTags($data->Id,'PostId');
    foreach ($tags as $key => $value) {
        array_push($tagsarray, $value->Tag);
    }
    if (count($tagsarray)>0) {
         $data->tags = implode(',', $tagsarray);
    }
    echo json_encode($data);

  }

   /* filter user posts by tag  */
  public function getAllBlogPostsByTag()
  {
    
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: *');
    $data = $this->post_model->getPosts($_POST['keyword']);
    echo json_encode($data);

  }

  /* filter users posts by tag */
  public function getUserPostsByTag($userid)
  {
    
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: *');
    $data = $this->post_model->getPostsByUser($userid,$_POST['keyword']);
    echo json_encode($data);

  }

  

}
